from __future__ import annotations

import json
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from infraswe.io import atomic_write_json
from infraswe.kernel.models import KernelAggregate, RoleResult
from infraswe.kernel.role_graph import RoleGraph
from infraswe.models.artifact import ArtifactManifest
from infraswe.models.evidence import LoadCellEvidence, ProfilerEvidence, RequestSample
from infraswe.models.gb10 import GB10CapabilityManifest
from infraswe.models.score import ScoreResult
from infraswe.models.task import TaskPackage


def schema_documents() -> dict[str, dict[str, Any]]:
    return {
        "task.schema.json": TaskPackage.model_json_schema(),
        "artifact.schema.json": ArtifactManifest.model_json_schema(),
        "result.schema.json": ScoreResult.model_json_schema(),
        "request-sample-v0.4.schema.json": RequestSample.model_json_schema(),
        "load-cell-v0.4.schema.json": LoadCellEvidence.model_json_schema(),
        "profiler-evidence-v0.4.schema.json": ProfilerEvidence.model_json_schema(),
        "gb10-capability.schema.json": GB10CapabilityManifest.model_json_schema(),
        "kernel-role-result.schema.json": RoleResult.model_json_schema(),
        "kernel-role-graph.schema.json": RoleGraph.model_json_schema(),
        "kernel-aggregate.schema.json": KernelAggregate.model_json_schema(),
    }


def write_schema_documents(output: Path) -> None:
    output.mkdir(parents=True, exist_ok=True)
    for name, schema in schema_documents().items():
        atomic_write_json(output / name, schema)


def rendered_schema_bytes(schema: Mapping[str, Any]) -> bytes:
    return (json.dumps(schema, indent=2, sort_keys=True) + "\n").encode()


def stale_schema_names(output: Path) -> list[str]:
    stale = []
    for name, schema in schema_documents().items():
        path = output / name
        if not path.is_file() or path.read_bytes() != rendered_schema_bytes(schema):
            stale.append(name)
    return stale
