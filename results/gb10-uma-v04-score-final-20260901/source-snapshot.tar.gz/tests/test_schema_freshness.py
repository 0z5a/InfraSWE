from __future__ import annotations

from infraswe.schema import schema_documents, stale_schema_names


def test_checked_in_protocol_schemas_match_models(project_root) -> None:
    assert stale_schema_names(project_root / "schemas") == []
    task_defs = schema_documents()["task.schema.json"]["$defs"]
    result_defs = schema_documents()["result.schema.json"]["$defs"]
    assert "KernelScoringConfig" in task_defs
    assert "ConcurrencyConfig" in task_defs
    assert "DeployabilityScore" in result_defs
    assert "CellEfficiencyScore" in result_defs
