# InfraSWE Trial 20260831T052623Z-nccl-topology-silent-fallback-2gpu-a4b0b2

- Task: `nccl-topology-silent-fallback-2gpu`
- State: `COMPLETED`
- Resolved@1: `true`
- StableResolved@1: `true`
- Core-100: `100.000`
- InfraExt-100: `100.000`
- InfraTotal: `100.000`
- Coverage: `100.0%`
- Hard-gate reasons: `none`

## Fresh replays

| Replay | Result | Seconds | Failure |
|---:|---|---:|---|
| 1 | PASS | 8.163 | - |
| 2 | PASS | 8.044 | - |
| 3 | PASS | 8.651 | - |

## Raw score components

```json
{
  "core_100": 100.0,
  "core_components": {
    "correctness": 1.0,
    "efficiency": 1.0,
    "fresh_replay": 1.0,
    "protocol": 1.0,
    "regression": 1.0
  },
  "coverage": 1.0,
  "gate": {
    "passed": true,
    "reasons": []
  },
  "infra_components": {
    "fault_recovery": 1.0,
    "observability": 1.0,
    "resource_efficiency": 1.0,
    "safety_rollback": 1.0,
    "slo_goodput": 1.0,
    "topology_robustness": 1.0
  },
  "infra_ext_100": 100.0,
  "infra_total": 100.0,
  "raw": {
    "catastrophic_gate": true,
    "manifest_valid": true,
    "protocol_gate": true,
    "replays": [
      {
        "assertions": {
          "functional.all_reduce_correct": true,
          "functional.two_ranks_completed": true,
          "mechanism.capability_matches_plan": true,
          "mechanism.nccl_transport_evidence": true,
          "regression.asymmetric_peer_matrix": true,
          "regression.complete_peer_matrix": true,
          "regression.unavailable_peer_matrix": true,
          "safety.explicit_fallback_when_required": true,
          "safety.resources_cleaned": true,
          "safety.zero_data_corruption": true,
          "slo.collective_latency": true
        },
        "duration_sec": 8.162634820000676,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "passed": true,
          "scenario": "p2p-unavailable",
          "score": 1.0
        },
        "index": 1,
        "message": "",
        "metrics": {
          "collective_p95_ms": 8.440832138061523,
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "launch_policy.py"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.all_reduce_correct": true,
          "functional.two_ranks_completed": true,
          "mechanism.capability_matches_plan": true,
          "mechanism.nccl_transport_evidence": true,
          "regression.asymmetric_peer_matrix": true,
          "regression.complete_peer_matrix": true,
          "regression.unavailable_peer_matrix": true,
          "safety.explicit_fallback_when_required": true,
          "safety.resources_cleaned": true,
          "safety.zero_data_corruption": true,
          "slo.collective_latency": true
        },
        "duration_sec": 8.043763396999566,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "passed": true,
          "scenario": "p2p-unavailable",
          "score": 1.0
        },
        "index": 2,
        "message": "",
        "metrics": {
          "collective_p95_ms": 7.056384086608887,
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "launch_policy.py"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.all_reduce_correct": true,
          "functional.two_ranks_completed": true,
          "mechanism.capability_matches_plan": true,
          "mechanism.nccl_transport_evidence": true,
          "regression.asymmetric_peer_matrix": true,
          "regression.complete_peer_matrix": true,
          "regression.unavailable_peer_matrix": true,
          "safety.explicit_fallback_when_required": true,
          "safety.resources_cleaned": true,
          "safety.zero_data_corruption": true,
          "slo.collective_latency": true
        },
        "duration_sec": 8.65144770599909,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "passed": true,
          "scenario": "p2p-unavailable",
          "score": 1.0
        },
        "index": 3,
        "message": "",
        "metrics": {
          "collective_p95_ms": 10.738688468933105,
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "launch_policy.py"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      }
    ],
    "usage": {
      "agent_time_sec": 0.549708587999703,
      "gpu_minutes": 0.8469184836999678,
      "infra_cost_usd": 0.0,
      "model_cost_usd": 0.0,
      "verifier_time_sec": 24.85784592299933,
      "wall_time_sec": 25.74449799699869
    }
  },
  "resolved_at_1": true,
  "schema_version": "0.1",
  "stable_resolved_at_1": true
}
```
