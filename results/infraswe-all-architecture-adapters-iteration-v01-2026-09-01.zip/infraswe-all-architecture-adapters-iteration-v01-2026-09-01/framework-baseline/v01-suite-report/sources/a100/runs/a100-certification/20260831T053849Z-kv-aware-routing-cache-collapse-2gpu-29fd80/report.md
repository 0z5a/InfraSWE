# InfraSWE Trial 20260831T053849Z-kv-aware-routing-cache-collapse-2gpu-29fd80

- Task: `kv-aware-routing-cache-collapse-2gpu`
- State: `COMPLETED`
- Resolved@1: `true`
- StableResolved@1: `true`
- Core-100: `100.000`
- InfraExt-100: `100.000`
- InfraTotal: `100.000`
- Coverage: `100.0%`
- Hard-gate reasons: `none`

## Fresh replays

| Replay | Result | Seconds | Failure |
|---:|---|---:|---|
| 1 | PASS | 3.161 | - |
| 2 | PASS | 3.088 | - |
| 3 | PASS | 3.242 | - |

## Raw score components

```json
{
  "core_100": 100.0,
  "core_components": {
    "correctness": 1.0,
    "efficiency": 1.0,
    "fresh_replay": 1.0,
    "protocol": 1.0,
    "regression": 1.0
  },
  "coverage": 1.0,
  "gate": {
    "passed": true,
    "reasons": []
  },
  "infra_components": {
    "fault_recovery": 1.0,
    "observability": 1.0,
    "resource_efficiency": 1.0,
    "safety_rollback": 1.0,
    "slo_goodput": 1.0,
    "topology_robustness": 1.0
  },
  "infra_ext_100": 100.0,
  "infra_total": 100.0,
  "raw": {
    "catastrophic_gate": true,
    "manifest_valid": true,
    "protocol_gate": true,
    "replays": [
      {
        "assertions": {
          "functional.all_requests_routed": true,
          "functional.two_gpu_execution": true,
          "functional.valid_worker_for_every_request": true,
          "mechanism.kv_affinity_declared": true,
          "mechanism.prefix_stability_observed": true,
          "regression.availability_aware": true,
          "regression.capacity_ceiling_preserved": true,
          "regression.input_immutable": true,
          "regression.malformed_input_rejected": true,
          "regression.prefix_route_deterministic": true,
          "regression.ttl_bounded": true,
          "safety.no_data_corruption": true,
          "safety.no_unavailable_worker_route": true,
          "safety.resources_cleaned": true,
          "safety.worker_recovered_within_deadline": true,
          "slo.cache_hit_ratio": true,
          "slo.error_rate": true,
          "slo.fairness": true,
          "slo.goodput": true,
          "slo.tail_latency": true
        },
        "duration_sec": 3.161208486999385,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "passed": true,
          "recovered_after_requests": 5,
          "scenario": "worker-0-unavailable",
          "score": 1.0
        },
        "index": 1,
        "message": "",
        "metrics": {
          "cache_hit_ratio": 0.8541666666666666,
          "error_rate": 0.0,
          "fairness_ratio": 0.8461538461538461,
          "observability_ratio": 1.0,
          "observed_slo_goodput_ratio": 0.8541666666666666,
          "p99_latency_ms": 12.0,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "router.py",
              "routing_config.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.all_requests_routed": true,
          "functional.two_gpu_execution": true,
          "functional.valid_worker_for_every_request": true,
          "mechanism.kv_affinity_declared": true,
          "mechanism.prefix_stability_observed": true,
          "regression.availability_aware": true,
          "regression.capacity_ceiling_preserved": true,
          "regression.input_immutable": true,
          "regression.malformed_input_rejected": true,
          "regression.prefix_route_deterministic": true,
          "regression.ttl_bounded": true,
          "safety.no_data_corruption": true,
          "safety.no_unavailable_worker_route": true,
          "safety.resources_cleaned": true,
          "safety.worker_recovered_within_deadline": true,
          "slo.cache_hit_ratio": true,
          "slo.error_rate": true,
          "slo.fairness": true,
          "slo.goodput": true,
          "slo.tail_latency": true
        },
        "duration_sec": 3.088258940000742,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "passed": true,
          "recovered_after_requests": 5,
          "scenario": "worker-0-unavailable",
          "score": 1.0
        },
        "index": 2,
        "message": "",
        "metrics": {
          "cache_hit_ratio": 0.8541666666666666,
          "error_rate": 0.0,
          "fairness_ratio": 0.8461538461538461,
          "observability_ratio": 1.0,
          "observed_slo_goodput_ratio": 0.8541666666666666,
          "p99_latency_ms": 12.0,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "router.py",
              "routing_config.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.all_requests_routed": true,
          "functional.two_gpu_execution": true,
          "functional.valid_worker_for_every_request": true,
          "mechanism.kv_affinity_declared": true,
          "mechanism.prefix_stability_observed": true,
          "regression.availability_aware": true,
          "regression.capacity_ceiling_preserved": true,
          "regression.input_immutable": true,
          "regression.malformed_input_rejected": true,
          "regression.prefix_route_deterministic": true,
          "regression.ttl_bounded": true,
          "safety.no_data_corruption": true,
          "safety.no_unavailable_worker_route": true,
          "safety.resources_cleaned": true,
          "safety.worker_recovered_within_deadline": true,
          "slo.cache_hit_ratio": true,
          "slo.error_rate": true,
          "slo.fairness": true,
          "slo.goodput": true,
          "slo.tail_latency": true
        },
        "duration_sec": 3.2416900909993274,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "passed": true,
          "recovered_after_requests": 5,
          "scenario": "worker-0-unavailable",
          "score": 1.0
        },
        "index": 3,
        "message": "",
        "metrics": {
          "cache_hit_ratio": 0.8541666666666666,
          "error_rate": 0.0,
          "fairness_ratio": 0.8461538461538461,
          "observability_ratio": 1.0,
          "observed_slo_goodput_ratio": 0.8541666666666666,
          "p99_latency_ms": 12.0,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "router.py",
              "routing_config.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      }
    ],
    "usage": {
      "agent_time_sec": 0.5116020710011071,
      "gpu_minutes": 0.33342531963335204,
      "infra_cost_usd": 0.0,
      "model_cost_usd": 0.0,
      "verifier_time_sec": 9.491157517999454,
      "wall_time_sec": 10.297465366000324
    }
  },
  "resolved_at_1": true,
  "schema_version": "0.1",
  "stable_resolved_at_1": true
}
```
