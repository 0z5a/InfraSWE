# InfraSWE Trial 20260831T055324Z-cuda-artifact-capability-selection-2f311f

- Task: `cuda-artifact-capability-selection`
- State: `COMPLETED`
- Resolved@1: `true`
- StableResolved@1: `true`
- Core-100: `100.000`
- InfraExt-100: `100.000`
- InfraTotal: `100.000`
- Coverage: `100.0%`
- Hard-gate reasons: `none`

## Fresh replays

| Replay | Result | Seconds | Failure |
|---:|---|---:|---|
| 1 | PASS | 3.169 | - |
| 2 | PASS | 3.042 | - |
| 3 | PASS | 3.094 | - |

## Raw score components

```json
{
  "core_100": 100.0,
  "core_components": {
    "correctness": 1.0,
    "efficiency": 1.0,
    "fresh_replay": 1.0,
    "protocol": 1.0,
    "regression": 1.0
  },
  "coverage": 1.0,
  "gate": {
    "passed": true,
    "reasons": []
  },
  "infra_components": {
    "fault_recovery": 1.0,
    "observability": 1.0,
    "resource_efficiency": 1.0,
    "safety_rollback": 1.0,
    "slo_goodput": 1.0,
    "topology_robustness": 1.0
  },
  "infra_ext_100": 100.0,
  "infra_total": 100.0,
  "raw": {
    "catastrophic_gate": true,
    "manifest_valid": true,
    "protocol_gate": true,
    "replays": [
      {
        "assertions": {
          "functional.actual_artifact_compatible": true,
          "functional.actual_gpu_kernel_correct": true,
          "functional.single_gpu_visible": true,
          "mechanism.abi_mismatch_blocked": true,
          "mechanism.driver_runtime_mismatch_blocked": true,
          "mechanism.ptx_fallback_explicit": true,
          "regression.abi_mismatch_blocked": true,
          "regression.artifact_order_independent": true,
          "regression.driver_runtime_mismatch_blocked": true,
          "regression.explicit_ptx_fallback": true,
          "regression.forward_compatible_ptx": true,
          "regression.input_immutable": true,
          "regression.malformed_request_rejected": true,
          "regression.native_precedence": true,
          "regression.policy_disables_cpu_fallback": true,
          "regression.policy_requires_explicit_fallback": true,
          "regression.policy_selection_order": true,
          "safety.explicit_fail_closed": true,
          "safety.no_cpu_fallback": true,
          "safety.no_data_corruption": true,
          "safety.resources_cleaned": true,
          "slo.selection_latency": true
        },
        "duration_sec": 3.1688018290005857,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "cxx11-abi-mismatch": true,
            "driver-runtime-mismatch": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 1,
        "message": "",
        "metrics": {
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "selection_p95_ms": 0.006853000741102733,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "build_policy.json",
              "selector.py"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.actual_artifact_compatible": true,
          "functional.actual_gpu_kernel_correct": true,
          "functional.single_gpu_visible": true,
          "mechanism.abi_mismatch_blocked": true,
          "mechanism.driver_runtime_mismatch_blocked": true,
          "mechanism.ptx_fallback_explicit": true,
          "regression.abi_mismatch_blocked": true,
          "regression.artifact_order_independent": true,
          "regression.driver_runtime_mismatch_blocked": true,
          "regression.explicit_ptx_fallback": true,
          "regression.forward_compatible_ptx": true,
          "regression.input_immutable": true,
          "regression.malformed_request_rejected": true,
          "regression.native_precedence": true,
          "regression.policy_disables_cpu_fallback": true,
          "regression.policy_requires_explicit_fallback": true,
          "regression.policy_selection_order": true,
          "safety.explicit_fail_closed": true,
          "safety.no_cpu_fallback": true,
          "safety.no_data_corruption": true,
          "safety.resources_cleaned": true,
          "slo.selection_latency": true
        },
        "duration_sec": 3.041657898000267,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "cxx11-abi-mismatch": true,
            "driver-runtime-mismatch": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 2,
        "message": "",
        "metrics": {
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "selection_p95_ms": 0.006551999831572175,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "build_policy.json",
              "selector.py"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.actual_artifact_compatible": true,
          "functional.actual_gpu_kernel_correct": true,
          "functional.single_gpu_visible": true,
          "mechanism.abi_mismatch_blocked": true,
          "mechanism.driver_runtime_mismatch_blocked": true,
          "mechanism.ptx_fallback_explicit": true,
          "regression.abi_mismatch_blocked": true,
          "regression.artifact_order_independent": true,
          "regression.driver_runtime_mismatch_blocked": true,
          "regression.explicit_ptx_fallback": true,
          "regression.forward_compatible_ptx": true,
          "regression.input_immutable": true,
          "regression.malformed_request_rejected": true,
          "regression.native_precedence": true,
          "regression.policy_disables_cpu_fallback": true,
          "regression.policy_requires_explicit_fallback": true,
          "regression.policy_selection_order": true,
          "safety.explicit_fail_closed": true,
          "safety.no_cpu_fallback": true,
          "safety.no_data_corruption": true,
          "safety.resources_cleaned": true,
          "slo.selection_latency": true
        },
        "duration_sec": 3.09401889900073,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "cxx11-abi-mismatch": true,
            "driver-runtime-mismatch": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 3,
        "message": "",
        "metrics": {
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "selection_p95_ms": 0.006551999831572175,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "build_policy.json",
              "selector.py"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      }
    ],
    "usage": {
      "agent_time_sec": 0.6766702170007193,
      "gpu_minutes": 0.16635248071670505,
      "infra_cost_usd": 0.0,
      "model_cost_usd": 0.0,
      "verifier_time_sec": 9.304478626001583,
      "wall_time_sec": 10.37581094000052
    }
  },
  "resolved_at_1": true,
  "schema_version": "0.1",
  "stable_resolved_at_1": true
}
```
