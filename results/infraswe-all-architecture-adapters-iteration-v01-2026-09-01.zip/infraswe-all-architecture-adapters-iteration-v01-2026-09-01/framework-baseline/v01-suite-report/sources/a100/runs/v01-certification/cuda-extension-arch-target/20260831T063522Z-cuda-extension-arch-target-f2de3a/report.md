# InfraSWE Trial 20260831T063522Z-cuda-extension-arch-target-f2de3a

- Task: `cuda-extension-arch-target`
- State: `COMPLETED`
- Resolved@1: `true`
- StableResolved@1: `true`
- Core-100: `100.000`
- InfraExt-100: `100.000`
- InfraTotal: `100.000`
- Coverage: `100.0%`
- Hard-gate reasons: `none`

## Fresh replays

| Replay | Result | Seconds | Failure |
|---:|---|---:|---|
| 1 | PASS | 2.827 | - |
| 2 | PASS | 2.797 | - |
| 3 | PASS | 2.708 | - |

## Raw score components

```json
{
  "core_100": 100.0,
  "core_components": {
    "correctness": 1.0,
    "efficiency": 1.0,
    "fresh_replay": 1.0,
    "protocol": 1.0,
    "regression": 1.0
  },
  "coverage": 1.0,
  "gate": {
    "passed": true,
    "reasons": []
  },
  "infra_components": {
    "fault_recovery": 1.0,
    "observability": 1.0,
    "resource_efficiency": 1.0,
    "safety_rollback": 1.0,
    "slo_goodput": 1.0,
    "topology_robustness": 1.0
  },
  "infra_ext_100": 100.0,
  "infra_total": 100.0,
  "raw": {
    "catastrophic_gate": true,
    "manifest_valid": true,
    "protocol_gate": true,
    "replays": [
      {
        "assertions": {
          "functional.actual_gpu_native_target": true,
          "functional.gpu_kernel_correct": true,
          "mechanism.native_sass_only": true,
          "mechanism.toolkit_capability_enforced": true,
          "regression.config_uses_visible_native_targets": true,
          "regression.input_immutable": true,
          "regression.malformed_fleet_rejected": true,
          "regression.mixed_fleet_targets_each_sm": true,
          "regression.order_independent": true,
          "regression.unsupported_sm_blocked": true,
          "safety.no_cross_generation_fallback": true,
          "safety.no_ptx_fallback": true,
          "safety.resources_cleaned": true,
          "slo.selection_latency": true
        },
        "duration_sec": 2.8270941429982486,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "mixed-sm-fleet": true,
            "unsupported-compiler-sm": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 1,
        "message": "",
        "metrics": {
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "selection_p95_ms": 0.0039670012483838946,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "arch_policy.py",
              "build_config.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.actual_gpu_native_target": true,
          "functional.gpu_kernel_correct": true,
          "mechanism.native_sass_only": true,
          "mechanism.toolkit_capability_enforced": true,
          "regression.config_uses_visible_native_targets": true,
          "regression.input_immutable": true,
          "regression.malformed_fleet_rejected": true,
          "regression.mixed_fleet_targets_each_sm": true,
          "regression.order_independent": true,
          "regression.unsupported_sm_blocked": true,
          "safety.no_cross_generation_fallback": true,
          "safety.no_ptx_fallback": true,
          "safety.resources_cleaned": true,
          "slo.selection_latency": true
        },
        "duration_sec": 2.7974418720004905,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "mixed-sm-fleet": true,
            "unsupported-compiler-sm": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 2,
        "message": "",
        "metrics": {
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "selection_p95_ms": 0.003697001375257969,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "arch_policy.py",
              "build_config.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.actual_gpu_native_target": true,
          "functional.gpu_kernel_correct": true,
          "mechanism.native_sass_only": true,
          "mechanism.toolkit_capability_enforced": true,
          "regression.config_uses_visible_native_targets": true,
          "regression.input_immutable": true,
          "regression.malformed_fleet_rejected": true,
          "regression.mixed_fleet_targets_each_sm": true,
          "regression.order_independent": true,
          "regression.unsupported_sm_blocked": true,
          "safety.no_cross_generation_fallback": true,
          "safety.no_ptx_fallback": true,
          "safety.resources_cleaned": true,
          "slo.selection_latency": true
        },
        "duration_sec": 2.7078460110024025,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "mixed-sm-fleet": true,
            "unsupported-compiler-sm": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 3,
        "message": "",
        "metrics": {
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "selection_p95_ms": 0.0039670012483838946,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "arch_policy.py",
              "build_config.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      }
    ],
    "usage": {
      "agent_time_sec": 0.8075441219989443,
      "gpu_minutes": 0.1523321024666681,
      "infra_cost_usd": 0.0,
      "model_cost_usd": 0.0,
      "verifier_time_sec": 8.332382026001142,
      "wall_time_sec": 9.567514031998144
    }
  },
  "resolved_at_1": true,
  "schema_version": "0.1",
  "stable_resolved_at_1": true
}
```
