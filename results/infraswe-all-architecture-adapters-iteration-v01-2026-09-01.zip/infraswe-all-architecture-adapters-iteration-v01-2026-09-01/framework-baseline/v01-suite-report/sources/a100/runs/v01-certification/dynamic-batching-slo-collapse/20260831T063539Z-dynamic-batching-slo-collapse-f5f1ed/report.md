# InfraSWE Trial 20260831T063539Z-dynamic-batching-slo-collapse-f5f1ed

- Task: `dynamic-batching-slo-collapse`
- State: `COMPLETED`
- Resolved@1: `true`
- StableResolved@1: `true`
- Core-100: `100.000`
- InfraExt-100: `100.000`
- InfraTotal: `100.000`
- Coverage: `100.0%`
- Hard-gate reasons: `none`

## Fresh replays

| Replay | Result | Seconds | Failure |
|---:|---|---:|---|
| 1 | PASS | 2.720 | - |
| 2 | PASS | 2.698 | - |
| 3 | PASS | 2.549 | - |

## Raw score components

```json
{
  "core_100": 100.0,
  "core_components": {
    "correctness": 1.0,
    "efficiency": 1.0,
    "fresh_replay": 1.0,
    "protocol": 1.0,
    "regression": 1.0
  },
  "coverage": 1.0,
  "gate": {
    "passed": true,
    "reasons": []
  },
  "infra_components": {
    "fault_recovery": 1.0,
    "observability": 1.0,
    "resource_efficiency": 1.0,
    "safety_rollback": 1.0,
    "slo_goodput": 1.0,
    "topology_robustness": 1.0
  },
  "infra_ext_100": 100.0,
  "infra_total": 100.0,
  "raw": {
    "catastrophic_gate": true,
    "manifest_valid": true,
    "protocol_gate": true,
    "replays": [
      {
        "assertions": {
          "functional.all_requests_scheduled_once": true,
          "functional.gpu_batches_correct": true,
          "mechanism.deadline_aware_microbatching": true,
          "mechanism.models_isolated": true,
          "regression.all_requests_once": true,
          "regression.batch_size_bounded": true,
          "regression.config_is_deadline_aware": true,
          "regression.input_immutable": true,
          "regression.malformed_input_rejected": true,
          "regression.model_isolated": true,
          "regression.order_independent": true,
          "regression.oversized_request_rejected": true,
          "regression.token_budget_bounded": true,
          "regression.wait_span_bounded": true,
          "safety.no_request_dropped": true,
          "safety.oversized_request_explicit": true,
          "safety.resources_cleaned": true,
          "slo.deadline_goodput": true,
          "slo.tail_latency": true
        },
        "duration_sec": 2.720410827001615,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "mixed-model-burst": true,
            "oversized-request": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 1,
        "message": "",
        "metrics": {
          "observability_ratio": 1.0,
          "p99_latency_ms": 6.45,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "batch_policy.py",
              "serving_config.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.all_requests_scheduled_once": true,
          "functional.gpu_batches_correct": true,
          "mechanism.deadline_aware_microbatching": true,
          "mechanism.models_isolated": true,
          "regression.all_requests_once": true,
          "regression.batch_size_bounded": true,
          "regression.config_is_deadline_aware": true,
          "regression.input_immutable": true,
          "regression.malformed_input_rejected": true,
          "regression.model_isolated": true,
          "regression.order_independent": true,
          "regression.oversized_request_rejected": true,
          "regression.token_budget_bounded": true,
          "regression.wait_span_bounded": true,
          "safety.no_request_dropped": true,
          "safety.oversized_request_explicit": true,
          "safety.resources_cleaned": true,
          "slo.deadline_goodput": true,
          "slo.tail_latency": true
        },
        "duration_sec": 2.698360007998417,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "mixed-model-burst": true,
            "oversized-request": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 2,
        "message": "",
        "metrics": {
          "observability_ratio": 1.0,
          "p99_latency_ms": 6.45,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "batch_policy.py",
              "serving_config.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.all_requests_scheduled_once": true,
          "functional.gpu_batches_correct": true,
          "mechanism.deadline_aware_microbatching": true,
          "mechanism.models_isolated": true,
          "regression.all_requests_once": true,
          "regression.batch_size_bounded": true,
          "regression.config_is_deadline_aware": true,
          "regression.input_immutable": true,
          "regression.malformed_input_rejected": true,
          "regression.model_isolated": true,
          "regression.order_independent": true,
          "regression.oversized_request_rejected": true,
          "regression.token_budget_bounded": true,
          "regression.wait_span_bounded": true,
          "safety.no_request_dropped": true,
          "safety.oversized_request_explicit": true,
          "safety.resources_cleaned": true,
          "slo.deadline_goodput": true,
          "slo.tail_latency": true
        },
        "duration_sec": 2.5489716949996364,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "mixed-model-burst": true,
            "oversized-request": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 3,
        "message": "",
        "metrics": {
          "observability_ratio": 1.0,
          "p99_latency_ms": 6.45,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "batch_policy.py",
              "serving_config.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      }
    ],
    "usage": {
      "agent_time_sec": 0.7503282750003564,
      "gpu_minutes": 0.14530118008333376,
      "infra_cost_usd": 0.0,
      "model_cost_usd": 0.0,
      "verifier_time_sec": 7.9677425299996685,
      "wall_time_sec": 9.152659895000397
    }
  },
  "resolved_at_1": true,
  "schema_version": "0.1",
  "stable_resolved_at_1": true
}
```
