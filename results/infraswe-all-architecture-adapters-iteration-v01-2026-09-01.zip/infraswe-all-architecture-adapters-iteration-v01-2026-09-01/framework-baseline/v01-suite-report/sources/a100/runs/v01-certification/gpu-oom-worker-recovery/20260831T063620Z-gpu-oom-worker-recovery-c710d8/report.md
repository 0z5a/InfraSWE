# InfraSWE Trial 20260831T063620Z-gpu-oom-worker-recovery-c710d8

- Task: `gpu-oom-worker-recovery`
- State: `COMPLETED`
- Resolved@1: `true`
- StableResolved@1: `true`
- Core-100: `100.000`
- InfraExt-100: `100.000`
- InfraTotal: `100.000`
- Coverage: `100.0%`
- Hard-gate reasons: `none`

## Fresh replays

| Replay | Result | Seconds | Failure |
|---:|---|---:|---|
| 1 | PASS | 4.732 | - |
| 2 | PASS | 4.775 | - |
| 3 | PASS | 4.721 | - |

## Raw score components

```json
{
  "core_100": 100.0,
  "core_components": {
    "correctness": 1.0,
    "efficiency": 1.0,
    "fresh_replay": 1.0,
    "protocol": 1.0,
    "regression": 1.0
  },
  "coverage": 1.0,
  "gate": {
    "passed": true,
    "reasons": []
  },
  "infra_components": {
    "fault_recovery": 1.0,
    "observability": 1.0,
    "resource_efficiency": 1.0,
    "safety_rollback": 1.0,
    "slo_goodput": 1.0,
    "topology_robustness": 1.0
  },
  "infra_ext_100": 100.0,
  "infra_total": 100.0,
  "raw": {
    "catastrophic_gate": true,
    "manifest_valid": true,
    "protocol_gate": true,
    "replays": [
      {
        "assertions": {
          "functional.all_failed_requests_retried": true,
          "functional.gpu_usable_after_oom": true,
          "mechanism.actual_cuda_oom_observed": true,
          "mechanism.failed_worker_cache_cleared": true,
          "mechanism.repeated_oom_quarantined": true,
          "regression.actual_cuda_oom_observed": true,
          "regression.deterministic": true,
          "regression.healthy_workers_preserved": true,
          "regression.input_immutable": true,
          "regression.malformed_event_rejected": true,
          "regression.minimum_batch_bounded": true,
          "regression.no_failover_fails_closed": true,
          "regression.repeated_oom_quarantined": true,
          "safety.healthy_workers_not_restarted": true,
          "safety.recovery_explicitly_reported": true,
          "safety.resources_cleaned": true,
          "slo.recovery_time": true,
          "slo.retry_goodput": true
        },
        "duration_sec": 4.731852836001053,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "actual-cuda-oom": true,
            "repeated-oom-quarantine": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 1,
        "message": "",
        "metrics": {
          "observability_ratio": 1.0,
          "recovery_goodput_ratio": 1.0,
          "recovery_seconds": 1.921594110001024,
          "resource_efficiency_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "recovery.py",
              "recovery_config.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.all_failed_requests_retried": true,
          "functional.gpu_usable_after_oom": true,
          "mechanism.actual_cuda_oom_observed": true,
          "mechanism.failed_worker_cache_cleared": true,
          "mechanism.repeated_oom_quarantined": true,
          "regression.actual_cuda_oom_observed": true,
          "regression.deterministic": true,
          "regression.healthy_workers_preserved": true,
          "regression.input_immutable": true,
          "regression.malformed_event_rejected": true,
          "regression.minimum_batch_bounded": true,
          "regression.no_failover_fails_closed": true,
          "regression.repeated_oom_quarantined": true,
          "safety.healthy_workers_not_restarted": true,
          "safety.recovery_explicitly_reported": true,
          "safety.resources_cleaned": true,
          "slo.recovery_time": true,
          "slo.retry_goodput": true
        },
        "duration_sec": 4.77538545599964,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "actual-cuda-oom": true,
            "repeated-oom-quarantine": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 2,
        "message": "",
        "metrics": {
          "observability_ratio": 1.0,
          "recovery_goodput_ratio": 1.0,
          "recovery_seconds": 2.136299556001177,
          "resource_efficiency_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "recovery.py",
              "recovery_config.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.all_failed_requests_retried": true,
          "functional.gpu_usable_after_oom": true,
          "mechanism.actual_cuda_oom_observed": true,
          "mechanism.failed_worker_cache_cleared": true,
          "mechanism.repeated_oom_quarantined": true,
          "regression.actual_cuda_oom_observed": true,
          "regression.deterministic": true,
          "regression.healthy_workers_preserved": true,
          "regression.input_immutable": true,
          "regression.malformed_event_rejected": true,
          "regression.minimum_batch_bounded": true,
          "regression.no_failover_fails_closed": true,
          "regression.repeated_oom_quarantined": true,
          "safety.healthy_workers_not_restarted": true,
          "safety.recovery_explicitly_reported": true,
          "safety.resources_cleaned": true,
          "slo.recovery_time": true,
          "slo.retry_goodput": true
        },
        "duration_sec": 4.721462413999689,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "actual-cuda-oom": true,
            "repeated-oom-quarantine": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 3,
        "message": "",
        "metrics": {
          "observability_ratio": 1.0,
          "recovery_goodput_ratio": 1.0,
          "recovery_seconds": 2.0819152939984633,
          "resource_efficiency_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "recovery.py",
              "recovery_config.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      }
    ],
    "usage": {
      "agent_time_sec": 0.7192065369999909,
      "gpu_minutes": 0.24913178738333952,
      "infra_cost_usd": 0.0,
      "model_cost_usd": 0.0,
      "verifier_time_sec": 14.228700706000382,
      "wall_time_sec": 15.425533098001324
    }
  },
  "resolved_at_1": true,
  "schema_version": "0.1",
  "stable_resolved_at_1": true
}
```
