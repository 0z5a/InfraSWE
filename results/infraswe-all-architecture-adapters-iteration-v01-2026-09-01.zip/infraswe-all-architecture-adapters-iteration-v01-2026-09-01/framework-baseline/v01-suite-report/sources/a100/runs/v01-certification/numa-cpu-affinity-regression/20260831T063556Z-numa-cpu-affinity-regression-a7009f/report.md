# InfraSWE Trial 20260831T063556Z-numa-cpu-affinity-regression-a7009f

- Task: `numa-cpu-affinity-regression`
- State: `COMPLETED`
- Resolved@1: `true`
- StableResolved@1: `true`
- Core-100: `100.000`
- InfraExt-100: `100.000`
- InfraTotal: `100.000`
- Coverage: `100.0%`
- Hard-gate reasons: `none`

## Fresh replays

| Replay | Result | Seconds | Failure |
|---:|---|---:|---|
| 1 | PASS | 2.747 | - |
| 2 | PASS | 2.830 | - |
| 3 | PASS | 2.755 | - |

## Raw score components

```json
{
  "core_100": 100.0,
  "core_components": {
    "correctness": 1.0,
    "efficiency": 1.0,
    "fresh_replay": 1.0,
    "protocol": 1.0,
    "regression": 1.0
  },
  "coverage": 1.0,
  "gate": {
    "passed": true,
    "reasons": []
  },
  "infra_components": {
    "fault_recovery": 1.0,
    "observability": 1.0,
    "resource_efficiency": 1.0,
    "safety_rollback": 1.0,
    "slo_goodput": 1.0,
    "topology_robustness": 1.0
  },
  "infra_ext_100": 100.0,
  "infra_total": 100.0,
  "raw": {
    "catastrophic_gate": true,
    "manifest_valid": true,
    "protocol_gate": true,
    "replays": [
      {
        "assertions": {
          "functional.actual_affinity_applied": true,
          "functional.gpu_kernel_correct": true,
          "mechanism.gpu_numa_local": true,
          "mechanism.reserved_cores_excluded": true,
          "regression.config_forbids_cross_numa": true,
          "regression.input_immutable": true,
          "regression.local_cores_exhausted_blocked": true,
          "regression.missing_numa_node_rejected": true,
          "regression.reserved_cpus_excluded": true,
          "regression.synthetic_gpu_local": true,
          "safety.affinity_restored": true,
          "safety.cross_numa_blocked": true,
          "safety.resources_cleaned": true,
          "slo.pinned_gpu_probe": true
        },
        "duration_sec": 2.7469374739994237,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "gpu-numa-node-missing": true,
            "local-cores-reserved": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 1,
        "message": "",
        "metrics": {
          "gpu_probe_ms": 0.013311999849975109,
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "affinity_config.json",
              "affinity_policy.py"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.actual_affinity_applied": true,
          "functional.gpu_kernel_correct": true,
          "mechanism.gpu_numa_local": true,
          "mechanism.reserved_cores_excluded": true,
          "regression.config_forbids_cross_numa": true,
          "regression.input_immutable": true,
          "regression.local_cores_exhausted_blocked": true,
          "regression.missing_numa_node_rejected": true,
          "regression.reserved_cpus_excluded": true,
          "regression.synthetic_gpu_local": true,
          "safety.affinity_restored": true,
          "safety.cross_numa_blocked": true,
          "safety.resources_cleaned": true,
          "slo.pinned_gpu_probe": true
        },
        "duration_sec": 2.8295619589989656,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "gpu-numa-node-missing": true,
            "local-cores-reserved": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 2,
        "message": "",
        "metrics": {
          "gpu_probe_ms": 0.013311999849975109,
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "affinity_config.json",
              "affinity_policy.py"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.actual_affinity_applied": true,
          "functional.gpu_kernel_correct": true,
          "mechanism.gpu_numa_local": true,
          "mechanism.reserved_cores_excluded": true,
          "regression.config_forbids_cross_numa": true,
          "regression.input_immutable": true,
          "regression.local_cores_exhausted_blocked": true,
          "regression.missing_numa_node_rejected": true,
          "regression.reserved_cpus_excluded": true,
          "regression.synthetic_gpu_local": true,
          "safety.affinity_restored": true,
          "safety.cross_numa_blocked": true,
          "safety.resources_cleaned": true,
          "slo.pinned_gpu_probe": true
        },
        "duration_sec": 2.755018381001719,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "gpu-numa-node-missing": true,
            "local-cores-reserved": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 3,
        "message": "",
        "metrics": {
          "gpu_probe_ms": 0.01228800043463707,
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "affinity_config.json",
              "affinity_policy.py"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      }
    ],
    "usage": {
      "agent_time_sec": 0.6394851059994835,
      "gpu_minutes": 0.14951671533332653,
      "infra_cost_usd": 0.0,
      "model_cost_usd": 0.0,
      "verifier_time_sec": 8.331517814000108,
      "wall_time_sec": 9.296218965999287
    }
  },
  "resolved_at_1": true,
  "schema_version": "0.1",
  "stable_resolved_at_1": true
}
```
