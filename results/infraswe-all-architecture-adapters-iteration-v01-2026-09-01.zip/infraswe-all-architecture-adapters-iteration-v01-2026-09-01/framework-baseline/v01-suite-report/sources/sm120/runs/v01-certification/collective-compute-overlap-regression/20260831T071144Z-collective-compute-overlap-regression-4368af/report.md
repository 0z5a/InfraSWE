# InfraSWE Trial 20260831T071144Z-collective-compute-overlap-regression-4368af

- Task: `collective-compute-overlap-regression`
- State: `COMPLETED`
- Resolved@1: `true`
- StableResolved@1: `true`
- Core-100: `100.000`
- InfraExt-100: `100.000`
- InfraTotal: `100.000`
- Coverage: `100.0%`
- Hard-gate reasons: `none`

## Fresh replays

| Replay | Result | Seconds | Failure |
|---:|---|---:|---|
| 1 | PASS | 13.741 | - |
| 2 | PASS | 8.405 | - |
| 3 | PASS | 14.342 | - |

## Raw score components

```json
{
  "core_100": 100.0,
  "core_components": {
    "correctness": 1.0,
    "efficiency": 1.0,
    "fresh_replay": 1.0,
    "protocol": 1.0,
    "regression": 1.0
  },
  "coverage": 1.0,
  "gate": {
    "passed": true,
    "reasons": []
  },
  "infra_components": {
    "fault_recovery": 1.0,
    "observability": 1.0,
    "resource_efficiency": 1.0,
    "safety_rollback": 1.0,
    "slo_goodput": 1.0,
    "topology_robustness": 1.0
  },
  "infra_ext_100": 100.0,
  "infra_total": 100.0,
  "raw": {
    "catastrophic_gate": true,
    "manifest_valid": true,
    "protocol_gate": true,
    "replays": [
      {
        "assertions": {
          "functional.collectives_correct": true,
          "functional.two_ranks_completed": true,
          "mechanism.async_comm_stream": true,
          "mechanism.event_fenced_pipeline": true,
          "regression.async_collectives": true,
          "regression.dedicated_comm_stream": true,
          "regression.event_fencing": true,
          "regression.input_immutable": true,
          "regression.malformed_input_rejected": true,
          "regression.order_independent": true,
          "regression.overlap_next_compute": true,
          "regression.ready_schema": true,
          "regression.stage_pipeline": true,
          "regression.unsafe_event_config_rejected": true,
          "regression.unsupported_topology_blocked": true,
          "safety.no_data_corruption": true,
          "safety.resources_cleaned": true,
          "safety.unsupported_topology_explicit": true,
          "slo.candidate_latency": true,
          "slo.overlap_speedup_observed": true
        },
        "duration_sec": 13.74055313899953,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "missing-event-fence": true,
            "serialized-default-stream": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 1,
        "message": "",
        "metrics": {
          "candidate_ms": 9.519725001155166,
          "observability_ratio": 1.0,
          "overlap_speedup_ratio": 1.0,
          "overlap_speedup_raw": 1.2845658880635806,
          "resource_efficiency_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "overlap_config.json",
              "overlap_policy.py"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.collectives_correct": true,
          "functional.two_ranks_completed": true,
          "mechanism.async_comm_stream": true,
          "mechanism.event_fenced_pipeline": true,
          "regression.async_collectives": true,
          "regression.dedicated_comm_stream": true,
          "regression.event_fencing": true,
          "regression.input_immutable": true,
          "regression.malformed_input_rejected": true,
          "regression.order_independent": true,
          "regression.overlap_next_compute": true,
          "regression.ready_schema": true,
          "regression.stage_pipeline": true,
          "regression.unsafe_event_config_rejected": true,
          "regression.unsupported_topology_blocked": true,
          "safety.no_data_corruption": true,
          "safety.resources_cleaned": true,
          "safety.unsupported_topology_explicit": true,
          "slo.candidate_latency": true,
          "slo.overlap_speedup_observed": true
        },
        "duration_sec": 8.405417182000747,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "missing-event-fence": true,
            "serialized-default-stream": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 2,
        "message": "",
        "metrics": {
          "candidate_ms": 9.50547499996901,
          "observability_ratio": 1.0,
          "overlap_speedup_ratio": 1.0,
          "overlap_speedup_raw": 1.2862475572592527,
          "resource_efficiency_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "overlap_config.json",
              "overlap_policy.py"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.collectives_correct": true,
          "functional.two_ranks_completed": true,
          "mechanism.async_comm_stream": true,
          "mechanism.event_fenced_pipeline": true,
          "regression.async_collectives": true,
          "regression.dedicated_comm_stream": true,
          "regression.event_fencing": true,
          "regression.input_immutable": true,
          "regression.malformed_input_rejected": true,
          "regression.order_independent": true,
          "regression.overlap_next_compute": true,
          "regression.ready_schema": true,
          "regression.stage_pipeline": true,
          "regression.unsafe_event_config_rejected": true,
          "regression.unsupported_topology_blocked": true,
          "safety.no_data_corruption": true,
          "safety.resources_cleaned": true,
          "safety.unsupported_topology_explicit": true,
          "slo.candidate_latency": true,
          "slo.overlap_speedup_observed": true
        },
        "duration_sec": 14.341849691998505,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "missing-event-fence": true,
            "serialized-default-stream": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 3,
        "message": "",
        "metrics": {
          "candidate_ms": 9.500284999376163,
          "observability_ratio": 1.0,
          "overlap_speedup_ratio": 1.0,
          "overlap_speedup_raw": 1.2872186467383993,
          "resource_efficiency_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "overlap_config.json",
              "overlap_policy.py"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      }
    ],
    "usage": {
      "agent_time_sec": 5.213110246000724,
      "gpu_minutes": 1.3900310086333167,
      "infra_cost_usd": 0.0,
      "model_cost_usd": 0.0,
      "verifier_time_sec": 36.48782001299878,
      "wall_time_sec": 46.48984246499822
    }
  },
  "resolved_at_1": true,
  "schema_version": "0.1",
  "stable_resolved_at_1": true
}
```
