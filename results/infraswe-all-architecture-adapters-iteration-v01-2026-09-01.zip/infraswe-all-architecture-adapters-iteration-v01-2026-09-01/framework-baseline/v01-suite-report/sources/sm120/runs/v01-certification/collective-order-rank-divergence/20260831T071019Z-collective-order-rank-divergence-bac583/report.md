# InfraSWE Trial 20260831T071019Z-collective-order-rank-divergence-bac583

- Task: `collective-order-rank-divergence`
- State: `COMPLETED`
- Resolved@1: `true`
- StableResolved@1: `true`
- Core-100: `100.000`
- InfraExt-100: `100.000`
- InfraTotal: `100.000`
- Coverage: `100.0%`
- Hard-gate reasons: `none`

## Fresh replays

| Replay | Result | Seconds | Failure |
|---:|---|---:|---|
| 1 | PASS | 14.841 | - |
| 2 | PASS | 14.392 | - |
| 3 | PASS | 15.372 | - |

## Raw score components

```json
{
  "core_100": 100.0,
  "core_components": {
    "correctness": 1.0,
    "efficiency": 1.0,
    "fresh_replay": 1.0,
    "protocol": 1.0,
    "regression": 1.0
  },
  "coverage": 1.0,
  "gate": {
    "passed": true,
    "reasons": []
  },
  "infra_components": {
    "fault_recovery": 1.0,
    "observability": 1.0,
    "resource_efficiency": 1.0,
    "safety_rollback": 1.0,
    "slo_goodput": 1.0,
    "topology_robustness": 1.0
  },
  "infra_ext_100": 100.0,
  "infra_total": 100.0,
  "raw": {
    "catastrophic_gate": true,
    "manifest_valid": true,
    "protocol_gate": true,
    "replays": [
      {
        "assertions": {
          "functional.collectives_correct": true,
          "functional.two_ranks_completed": true,
          "mechanism.canonical_order_before_nccl": true,
          "mechanism.rank_divergence_detected": true,
          "regression.canonical_schedule": true,
          "regression.divergence_reported": true,
          "regression.fingerprint_valid": true,
          "regression.input_immutable": true,
          "regression.malformed_input_rejected": true,
          "regression.metadata_mismatch_blocked": true,
          "regression.missing_collective_blocked": true,
          "regression.order_independent": true,
          "regression.rank_schedules_identical": true,
          "regression.ready_schema": true,
          "safety.mismatched_metadata_blocked": true,
          "safety.no_data_corruption": true,
          "safety.resources_cleaned": true,
          "slo.collective_latency": true
        },
        "duration_sec": 14.840561873999832,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "collective-metadata-mismatch": true,
            "rank-order-divergence": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 1,
        "message": "",
        "metrics": {
          "collective_goodput_ratio": 1.0,
          "collective_ms": 1.0108159929513931,
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "collective_policy.py",
              "order_config.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.collectives_correct": true,
          "functional.two_ranks_completed": true,
          "mechanism.canonical_order_before_nccl": true,
          "mechanism.rank_divergence_detected": true,
          "regression.canonical_schedule": true,
          "regression.divergence_reported": true,
          "regression.fingerprint_valid": true,
          "regression.input_immutable": true,
          "regression.malformed_input_rejected": true,
          "regression.metadata_mismatch_blocked": true,
          "regression.missing_collective_blocked": true,
          "regression.order_independent": true,
          "regression.rank_schedules_identical": true,
          "regression.ready_schema": true,
          "safety.mismatched_metadata_blocked": true,
          "safety.no_data_corruption": true,
          "safety.resources_cleaned": true,
          "slo.collective_latency": true
        },
        "duration_sec": 14.392018866999933,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "collective-metadata-mismatch": true,
            "rank-order-divergence": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 2,
        "message": "",
        "metrics": {
          "collective_goodput_ratio": 1.0,
          "collective_ms": 33.079647958278656,
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "collective_policy.py",
              "order_config.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.collectives_correct": true,
          "functional.two_ranks_completed": true,
          "mechanism.canonical_order_before_nccl": true,
          "mechanism.rank_divergence_detected": true,
          "regression.canonical_schedule": true,
          "regression.divergence_reported": true,
          "regression.fingerprint_valid": true,
          "regression.input_immutable": true,
          "regression.malformed_input_rejected": true,
          "regression.metadata_mismatch_blocked": true,
          "regression.missing_collective_blocked": true,
          "regression.order_independent": true,
          "regression.rank_schedules_identical": true,
          "regression.ready_schema": true,
          "safety.mismatched_metadata_blocked": true,
          "safety.no_data_corruption": true,
          "safety.resources_cleaned": true,
          "slo.collective_latency": true
        },
        "duration_sec": 15.372151919998942,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "collective-metadata-mismatch": true,
            "rank-order-divergence": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 3,
        "message": "",
        "metrics": {
          "collective_goodput_ratio": 1.0,
          "collective_ms": 0.5807680189609528,
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "collective_policy.py",
              "order_config.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      }
    ],
    "usage": {
      "agent_time_sec": 5.078336243001104,
      "gpu_minutes": 1.6561022967999937,
      "infra_cost_usd": 0.0,
      "model_cost_usd": 0.0,
      "verifier_time_sec": 44.60473266099871,
      "wall_time_sec": 54.42173874099899
    }
  },
  "resolved_at_1": true,
  "schema_version": "0.1",
  "stable_resolved_at_1": true
}
```
