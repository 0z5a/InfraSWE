# InfraSWE Trial 20260831T061128Z-container-image-dependency-lock-2f1ab0

- Task: `container-image-dependency-lock`
- State: `COMPLETED`
- Resolved@1: `true`
- StableResolved@1: `true`
- Core-100: `96.764`
- InfraExt-100: `100.000`
- InfraTotal: `98.693`
- Coverage: `100.0%`
- Hard-gate reasons: `none`

## Fresh replays

| Replay | Result | Seconds | Failure |
|---:|---|---:|---|
| 1 | PASS | 0.666 | - |
| 2 | PASS | 0.625 | - |
| 3 | PASS | 0.633 | - |

## Raw score components

```json
{
  "core_100": 96.764,
  "core_components": {
    "correctness": 1.0,
    "efficiency": 0.676400037411682,
    "fresh_replay": 1.0,
    "protocol": 1.0,
    "regression": 1.0
  },
  "coverage": 1.0,
  "gate": {
    "passed": true,
    "reasons": []
  },
  "infra_components": {
    "fault_recovery": 1.0,
    "observability": 1.0,
    "resource_efficiency": 1.0,
    "safety_rollback": 1.0,
    "slo_goodput": 1.0,
    "topology_robustness": 1.0
  },
  "infra_ext_100": 100.0,
  "infra_total": 98.692812,
  "raw": {
    "catastrophic_gate": true,
    "manifest_valid": true,
    "protocol_gate": true,
    "replays": [
      {
        "assertions": {
          "functional.actual_platform_lock_resolved": true,
          "functional.immutable_candidate_selected": true,
          "mechanism.digest_enforced": true,
          "mechanism.transitive_conflict_rejected": true,
          "regression.architecture_mismatch_blocked": true,
          "regression.artifact_order_independent": true,
          "regression.dependency_conflict_blocked": true,
          "regression.input_immutable": true,
          "regression.malformed_request_rejected": true,
          "regression.policy_is_immutable": true,
          "regression.unpinned_dependency_blocked": true,
          "safety.cross_architecture_blocked": true,
          "safety.inputs_unchanged": true,
          "safety.no_mutable_fallback": true,
          "safety.resources_cleaned": true,
          "slo.selection_latency": true
        },
        "duration_sec": 0.6658237030005694,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "architecture-mismatch": true,
            "dependency-conflict": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 1,
        "message": "",
        "metrics": {
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "selection_p95_ms": 0.009479999789618887,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "lock_policy.json",
              "resolver.py"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.actual_platform_lock_resolved": true,
          "functional.immutable_candidate_selected": true,
          "mechanism.digest_enforced": true,
          "mechanism.transitive_conflict_rejected": true,
          "regression.architecture_mismatch_blocked": true,
          "regression.artifact_order_independent": true,
          "regression.dependency_conflict_blocked": true,
          "regression.input_immutable": true,
          "regression.malformed_request_rejected": true,
          "regression.policy_is_immutable": true,
          "regression.unpinned_dependency_blocked": true,
          "safety.cross_architecture_blocked": true,
          "safety.inputs_unchanged": true,
          "safety.no_mutable_fallback": true,
          "safety.resources_cleaned": true,
          "slo.selection_latency": true
        },
        "duration_sec": 0.6254515029995673,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "architecture-mismatch": true,
            "dependency-conflict": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 2,
        "message": "",
        "metrics": {
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "selection_p95_ms": 0.00971000008576084,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "lock_policy.json",
              "resolver.py"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.actual_platform_lock_resolved": true,
          "functional.immutable_candidate_selected": true,
          "mechanism.digest_enforced": true,
          "mechanism.transitive_conflict_rejected": true,
          "regression.architecture_mismatch_blocked": true,
          "regression.artifact_order_independent": true,
          "regression.dependency_conflict_blocked": true,
          "regression.input_immutable": true,
          "regression.malformed_request_rejected": true,
          "regression.policy_is_immutable": true,
          "regression.unpinned_dependency_blocked": true,
          "safety.cross_architecture_blocked": true,
          "safety.inputs_unchanged": true,
          "safety.no_mutable_fallback": true,
          "safety.resources_cleaned": true,
          "slo.selection_latency": true
        },
        "duration_sec": 0.6328637879996677,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "architecture-mismatch": true,
            "dependency-conflict": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 3,
        "message": "",
        "metrics": {
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "selection_p95_ms": 0.009970000064640772,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "lock_policy.json",
              "resolver.py"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      }
    ],
    "usage": {
      "agent_time_sec": 0.578429443999994,
      "gpu_minutes": 0.0,
      "infra_cost_usd": 0.0,
      "model_cost_usd": 0.0,
      "verifier_time_sec": 1.9241389939998044,
      "wall_time_sec": 7.392075285999454
    }
  },
  "resolved_at_1": true,
  "schema_version": "0.1",
  "stable_resolved_at_1": true
}
```
