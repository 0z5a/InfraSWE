# InfraSWE Trial 20260831T061143Z-gpu-resource-request-contract-391e93

- Task: `gpu-resource-request-contract`
- State: `COMPLETED`
- Resolved@1: `true`
- StableResolved@1: `true`
- Core-100: `96.725`
- InfraExt-100: `100.000`
- InfraTotal: `98.677`
- Coverage: `100.0%`
- Hard-gate reasons: `none`

## Fresh replays

| Replay | Result | Seconds | Failure |
|---:|---|---:|---|
| 1 | PASS | 0.622 | - |
| 2 | PASS | 0.646 | - |
| 3 | PASS | 0.641 | - |

## Raw score components

```json
{
  "core_100": 96.724725,
  "core_components": {
    "correctness": 1.0,
    "efficiency": 0.6724725474403519,
    "fresh_replay": 1.0,
    "protocol": 1.0,
    "regression": 1.0
  },
  "coverage": 1.0,
  "gate": {
    "passed": true,
    "reasons": []
  },
  "infra_components": {
    "fault_recovery": 1.0,
    "observability": 1.0,
    "resource_efficiency": 1.0,
    "safety_rollback": 1.0,
    "slo_goodput": 1.0,
    "topology_robustness": 1.0
  },
  "infra_ext_100": 100.0,
  "infra_total": 98.676787,
  "raw": {
    "catastrophic_gate": true,
    "manifest_valid": true,
    "protocol_gate": true,
    "replays": [
      {
        "assertions": {
          "functional.gpu_workload_admitted": true,
          "functional.public_contract_preserved": true,
          "mechanism.capability_selector_enforced": true,
          "mechanism.requests_equal_limits": true,
          "mechanism.runtime_class_enforced": true,
          "regression.capability_mismatch_rejected": true,
          "regression.capacity_exhausted_rejected": true,
          "regression.input_immutable": true,
          "regression.malformed_input_rejected": true,
          "regression.missing_gpu_request_rejected": true,
          "regression.runtime_unavailable_rejected": true,
          "regression.unequal_request_limit_rejected": true,
          "regression.workload_invariants": true,
          "safety.capacity_failure_explicit": true,
          "safety.no_cpu_fallback": true,
          "safety.resources_cleaned": true,
          "slo.admission_latency": true
        },
        "duration_sec": 0.622057443999438,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "gpu-capacity-exhausted": true,
            "nvidia-runtime-unavailable": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 1,
        "message": "",
        "metrics": {
          "admission_p95_ms": 0.003480000486888457,
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "admission.py",
              "workload.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.gpu_workload_admitted": true,
          "functional.public_contract_preserved": true,
          "mechanism.capability_selector_enforced": true,
          "mechanism.requests_equal_limits": true,
          "mechanism.runtime_class_enforced": true,
          "regression.capability_mismatch_rejected": true,
          "regression.capacity_exhausted_rejected": true,
          "regression.input_immutable": true,
          "regression.malformed_input_rejected": true,
          "regression.missing_gpu_request_rejected": true,
          "regression.runtime_unavailable_rejected": true,
          "regression.unequal_request_limit_rejected": true,
          "regression.workload_invariants": true,
          "safety.capacity_failure_explicit": true,
          "safety.no_cpu_fallback": true,
          "safety.resources_cleaned": true,
          "slo.admission_latency": true
        },
        "duration_sec": 0.6455879539998932,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "gpu-capacity-exhausted": true,
            "nvidia-runtime-unavailable": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 2,
        "message": "",
        "metrics": {
          "admission_p95_ms": 0.003390000529179815,
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "admission.py",
              "workload.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.gpu_workload_admitted": true,
          "functional.public_contract_preserved": true,
          "mechanism.capability_selector_enforced": true,
          "mechanism.requests_equal_limits": true,
          "mechanism.runtime_class_enforced": true,
          "regression.capability_mismatch_rejected": true,
          "regression.capacity_exhausted_rejected": true,
          "regression.input_immutable": true,
          "regression.malformed_input_rejected": true,
          "regression.missing_gpu_request_rejected": true,
          "regression.runtime_unavailable_rejected": true,
          "regression.unequal_request_limit_rejected": true,
          "regression.workload_invariants": true,
          "safety.capacity_failure_explicit": true,
          "safety.no_cpu_fallback": true,
          "safety.resources_cleaned": true,
          "slo.admission_latency": true
        },
        "duration_sec": 0.6413064289999966,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "gpu-capacity-exhausted": true,
            "nvidia-runtime-unavailable": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 3,
        "message": "",
        "metrics": {
          "admission_p95_ms": 0.0033599999369471334,
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "admission.py",
              "workload.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      }
    ],
    "usage": {
      "agent_time_sec": 0.5844156909997764,
      "gpu_minutes": 0.0,
      "infra_cost_usd": 0.0,
      "model_cost_usd": 0.0,
      "verifier_time_sec": 1.9089518269993277,
      "wall_time_sec": 7.43524775700007
    }
  },
  "resolved_at_1": true,
  "schema_version": "0.1",
  "stable_resolved_at_1": true
}
```
