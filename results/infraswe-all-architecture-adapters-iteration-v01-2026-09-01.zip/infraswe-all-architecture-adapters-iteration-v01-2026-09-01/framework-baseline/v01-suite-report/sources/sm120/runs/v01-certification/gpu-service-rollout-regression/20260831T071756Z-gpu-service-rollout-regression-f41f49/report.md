# InfraSWE Trial 20260831T071756Z-gpu-service-rollout-regression-f41f49

- Task: `gpu-service-rollout-regression`
- State: `COMPLETED`
- Resolved@1: `true`
- StableResolved@1: `true`
- Core-100: `96.872`
- InfraExt-100: `100.000`
- InfraTotal: `98.737`
- Coverage: `100.0%`
- Hard-gate reasons: `none`

## Fresh replays

| Replay | Result | Seconds | Failure |
|---:|---|---:|---|
| 1 | PASS | 0.656 | - |
| 2 | PASS | 0.673 | - |
| 3 | PASS | 0.633 | - |

## Raw score components

```json
{
  "core_100": 96.87228,
  "core_components": {
    "correctness": 1.0,
    "efficiency": 0.6872279936653779,
    "fresh_replay": 1.0,
    "protocol": 1.0,
    "regression": 1.0
  },
  "coverage": 1.0,
  "gate": {
    "passed": true,
    "reasons": []
  },
  "infra_components": {
    "fault_recovery": 1.0,
    "observability": 1.0,
    "resource_efficiency": 1.0,
    "safety_rollback": 1.0,
    "slo_goodput": 1.0,
    "topology_robustness": 1.0
  },
  "infra_ext_100": 100.0,
  "infra_total": 98.736973,
  "raw": {
    "catastrophic_gate": true,
    "manifest_valid": true,
    "protocol_gate": true,
    "replays": [
      {
        "assertions": {
          "functional.ready_endpoint_selected": true,
          "functional.response_integrity": true,
          "functional.zero_rollout_errors": true,
          "regression.image_preserved": true,
          "regression.port_preserved": true,
          "regression.replica_count_preserved": true,
          "safety.resources_cleaned": true,
          "safety.rollback_completed": true,
          "safety.zero_data_corruption": true,
          "slo.goodput_budget": true,
          "slo.recovery_time": true
        },
        "duration_sec": 0.6564479330008908,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "passed": true,
          "score": 1.0,
          "termination_recovery_seconds": 2.0
        },
        "index": 1,
        "message": "",
        "metrics": {
          "dropped_requests": 0.0,
          "observability_ratio": 1.0,
          "recovery_time_seconds": 2.0,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "deployment.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.ready_endpoint_selected": true,
          "functional.response_integrity": true,
          "functional.zero_rollout_errors": true,
          "regression.image_preserved": true,
          "regression.port_preserved": true,
          "regression.replica_count_preserved": true,
          "safety.resources_cleaned": true,
          "safety.rollback_completed": true,
          "safety.zero_data_corruption": true,
          "slo.goodput_budget": true,
          "slo.recovery_time": true
        },
        "duration_sec": 0.6731714609995834,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "passed": true,
          "score": 1.0,
          "termination_recovery_seconds": 2.0
        },
        "index": 2,
        "message": "",
        "metrics": {
          "dropped_requests": 0.0,
          "observability_ratio": 1.0,
          "recovery_time_seconds": 2.0,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "deployment.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.ready_endpoint_selected": true,
          "functional.response_integrity": true,
          "functional.zero_rollout_errors": true,
          "regression.image_preserved": true,
          "regression.port_preserved": true,
          "regression.replica_count_preserved": true,
          "safety.resources_cleaned": true,
          "safety.rollback_completed": true,
          "safety.zero_data_corruption": true,
          "slo.goodput_budget": true,
          "slo.recovery_time": true
        },
        "duration_sec": 0.632793632999892,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "passed": true,
          "score": 1.0,
          "termination_recovery_seconds": 2.0
        },
        "index": 3,
        "message": "",
        "metrics": {
          "dropped_requests": 0.0,
          "observability_ratio": 1.0,
          "recovery_time_seconds": 2.0,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "deployment.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      }
    ],
    "usage": {
      "agent_time_sec": 0.5733205870001257,
      "gpu_minutes": 0.0,
      "infra_cost_usd": 0.0,
      "model_cost_usd": 0.0,
      "verifier_time_sec": 1.9624130270003661,
      "wall_time_sec": 7.275605834000089
    }
  },
  "resolved_at_1": true,
  "schema_version": "0.1",
  "stable_resolved_at_1": true
}
```
