# InfraSWE Trial 20260831T061157Z-health-probe-drain-regression-172ca7

- Task: `health-probe-drain-regression`
- State: `COMPLETED`
- Resolved@1: `true`
- StableResolved@1: `true`
- Core-100: `96.948`
- InfraExt-100: `100.000`
- InfraTotal: `98.768`
- Coverage: `100.0%`
- Hard-gate reasons: `none`

## Fresh replays

| Replay | Result | Seconds | Failure |
|---:|---|---:|---|
| 1 | PASS | 0.616 | - |
| 2 | PASS | 0.622 | - |
| 3 | PASS | 0.613 | - |

## Raw score components

```json
{
  "core_100": 96.948278,
  "core_components": {
    "correctness": 1.0,
    "efficiency": 0.6948278163675746,
    "fresh_replay": 1.0,
    "protocol": 1.0,
    "regression": 1.0
  },
  "coverage": 1.0,
  "gate": {
    "passed": true,
    "reasons": []
  },
  "infra_components": {
    "fault_recovery": 1.0,
    "observability": 1.0,
    "resource_efficiency": 1.0,
    "safety_rollback": 1.0,
    "slo_goodput": 1.0,
    "topology_robustness": 1.0
  },
  "infra_ext_100": 100.0,
  "infra_total": 98.76795,
  "raw": {
    "catastrophic_gate": true,
    "manifest_valid": true,
    "protocol_gate": true,
    "replays": [
      {
        "assertions": {
          "functional.response_integrity": true,
          "functional.zero_rollout_errors": true,
          "mechanism.readiness_controls_traffic": true,
          "mechanism.termination_drains_inflight": true,
          "regression.capacity_preserved": true,
          "regression.drain_endpoint_used": true,
          "regression.higher_inflight_bound_rejected": true,
          "regression.input_immutable": true,
          "regression.malformed_input_rejected": true,
          "regression.public_contract_preserved": true,
          "regression.readiness_endpoint_used": true,
          "regression.termination_grace_safe": true,
          "safety.resources_cleaned": true,
          "safety.rollback_completed": true,
          "safety.zero_data_corruption": true,
          "slo.goodput": true,
          "slo.recovery_time": true
        },
        "duration_sec": 0.615880561999802,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "readiness-flap": true,
            "sigterm-inflight": true
          },
          "passed": true,
          "recovery_seconds": 4.0,
          "score": 1.0
        },
        "index": 1,
        "message": "",
        "metrics": {
          "dropped_requests": 0.0,
          "observability_ratio": 1.0,
          "recovery_seconds": 4.0,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "deployment.json",
              "probe_policy.py"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.response_integrity": true,
          "functional.zero_rollout_errors": true,
          "mechanism.readiness_controls_traffic": true,
          "mechanism.termination_drains_inflight": true,
          "regression.capacity_preserved": true,
          "regression.drain_endpoint_used": true,
          "regression.higher_inflight_bound_rejected": true,
          "regression.input_immutable": true,
          "regression.malformed_input_rejected": true,
          "regression.public_contract_preserved": true,
          "regression.readiness_endpoint_used": true,
          "regression.termination_grace_safe": true,
          "safety.resources_cleaned": true,
          "safety.rollback_completed": true,
          "safety.zero_data_corruption": true,
          "slo.goodput": true,
          "slo.recovery_time": true
        },
        "duration_sec": 0.6224581710002894,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "readiness-flap": true,
            "sigterm-inflight": true
          },
          "passed": true,
          "recovery_seconds": 4.0,
          "score": 1.0
        },
        "index": 2,
        "message": "",
        "metrics": {
          "dropped_requests": 0.0,
          "observability_ratio": 1.0,
          "recovery_seconds": 4.0,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "deployment.json",
              "probe_policy.py"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.response_integrity": true,
          "functional.zero_rollout_errors": true,
          "mechanism.readiness_controls_traffic": true,
          "mechanism.termination_drains_inflight": true,
          "regression.capacity_preserved": true,
          "regression.drain_endpoint_used": true,
          "regression.higher_inflight_bound_rejected": true,
          "regression.input_immutable": true,
          "regression.malformed_input_rejected": true,
          "regression.public_contract_preserved": true,
          "regression.readiness_endpoint_used": true,
          "regression.termination_grace_safe": true,
          "safety.resources_cleaned": true,
          "safety.rollback_completed": true,
          "safety.zero_data_corruption": true,
          "slo.goodput": true,
          "slo.recovery_time": true
        },
        "duration_sec": 0.6127997249996042,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "readiness-flap": true,
            "sigterm-inflight": true
          },
          "passed": true,
          "recovery_seconds": 4.0,
          "score": 1.0
        },
        "index": 3,
        "message": "",
        "metrics": {
          "dropped_requests": 0.0,
          "observability_ratio": 1.0,
          "recovery_seconds": 4.0,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "deployment.json",
              "probe_policy.py"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      }
    ],
    "usage": {
      "agent_time_sec": 0.5656191829993986,
      "gpu_minutes": 0.0,
      "infra_cost_usd": 0.0,
      "model_cost_usd": 0.0,
      "verifier_time_sec": 1.8511384579996957,
      "wall_time_sec": 7.196027393000804
    }
  },
  "resolved_at_1": true,
  "schema_version": "0.1",
  "stable_resolved_at_1": true
}
```
