# InfraSWE Trial 20260831T071317Z-rank-exit-collective-recovery-e74fb3

- Task: `rank-exit-collective-recovery`
- State: `COMPLETED`
- Resolved@1: `true`
- StableResolved@1: `true`
- Core-100: `100.000`
- InfraExt-100: `100.000`
- InfraTotal: `100.000`
- Coverage: `100.0%`
- Hard-gate reasons: `none`

## Fresh replays

| Replay | Result | Seconds | Failure |
|---:|---|---:|---|
| 1 | PASS | 19.687 | - |
| 2 | PASS | 18.990 | - |
| 3 | PASS | 18.705 | - |

## Raw score components

```json
{
  "core_100": 100.0,
  "core_components": {
    "correctness": 1.0,
    "efficiency": 1.0,
    "fresh_replay": 1.0,
    "protocol": 1.0,
    "regression": 1.0
  },
  "coverage": 1.0,
  "gate": {
    "passed": true,
    "reasons": []
  },
  "infra_components": {
    "fault_recovery": 1.0,
    "observability": 1.0,
    "resource_efficiency": 1.0,
    "safety_rollback": 1.0,
    "slo_goodput": 1.0,
    "topology_robustness": 1.0
  },
  "infra_ext_100": 100.0,
  "infra_total": 100.0,
  "raw": {
    "catastrophic_gate": true,
    "manifest_valid": true,
    "protocol_gate": true,
    "replays": [
      {
        "assertions": {
          "functional.actual_rank_exit_observed": true,
          "functional.recovered_collective_correct": true,
          "functional.two_ranks_rejoined": true,
          "mechanism.full_group_reinitialized": true,
          "mechanism.resumed_last_checkpoint": true,
          "regression.checkpoint_resume": true,
          "regression.deterministic": true,
          "regression.full_group_abort": true,
          "regression.input_immutable": true,
          "regression.malformed_event_rejected": true,
          "regression.restart_budget_enforced": true,
          "regression.world_size_shrink_rejected": true,
          "safety.no_world_size_shrink": true,
          "safety.resources_cleaned": true,
          "safety.restart_budget_explicit": true,
          "slo.failure_detection": true,
          "slo.recovery_time": true,
          "slo.replay_goodput": true
        },
        "duration_sec": 19.687475156999426,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "abrupt-rank-exit": true,
            "restart-budget-exhausted": true
          },
          "detection_seconds": 4.686280722999072,
          "passed": true,
          "score": 1.0
        },
        "index": 1,
        "message": "",
        "metrics": {
          "failure_detection_seconds": 4.686280722999072,
          "observability_ratio": 1.0,
          "recovery_goodput_ratio": 1.0,
          "recovery_seconds": 5.390788234999491,
          "resource_efficiency_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "failure_policy.py",
              "recovery_config.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.actual_rank_exit_observed": true,
          "functional.recovered_collective_correct": true,
          "functional.two_ranks_rejoined": true,
          "mechanism.full_group_reinitialized": true,
          "mechanism.resumed_last_checkpoint": true,
          "regression.checkpoint_resume": true,
          "regression.deterministic": true,
          "regression.full_group_abort": true,
          "regression.input_immutable": true,
          "regression.malformed_event_rejected": true,
          "regression.restart_budget_enforced": true,
          "regression.world_size_shrink_rejected": true,
          "safety.no_world_size_shrink": true,
          "safety.resources_cleaned": true,
          "safety.restart_budget_explicit": true,
          "slo.failure_detection": true,
          "slo.recovery_time": true,
          "slo.replay_goodput": true
        },
        "duration_sec": 18.989690904998497,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "abrupt-rank-exit": true,
            "restart-budget-exhausted": true
          },
          "detection_seconds": 4.663392070000555,
          "passed": true,
          "score": 1.0
        },
        "index": 2,
        "message": "",
        "metrics": {
          "failure_detection_seconds": 4.663392070000555,
          "observability_ratio": 1.0,
          "recovery_goodput_ratio": 1.0,
          "recovery_seconds": 5.26219841800048,
          "resource_efficiency_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "failure_policy.py",
              "recovery_config.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.actual_rank_exit_observed": true,
          "functional.recovered_collective_correct": true,
          "functional.two_ranks_rejoined": true,
          "mechanism.full_group_reinitialized": true,
          "mechanism.resumed_last_checkpoint": true,
          "regression.checkpoint_resume": true,
          "regression.deterministic": true,
          "regression.full_group_abort": true,
          "regression.input_immutable": true,
          "regression.malformed_event_rejected": true,
          "regression.restart_budget_enforced": true,
          "regression.world_size_shrink_rejected": true,
          "safety.no_world_size_shrink": true,
          "safety.resources_cleaned": true,
          "safety.restart_budget_explicit": true,
          "slo.failure_detection": true,
          "slo.recovery_time": true,
          "slo.replay_goodput": true
        },
        "duration_sec": 18.705182600000626,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "abrupt-rank-exit": true,
            "restart-budget-exhausted": true
          },
          "detection_seconds": 4.659819905000404,
          "passed": true,
          "score": 1.0
        },
        "index": 3,
        "message": "",
        "metrics": {
          "failure_detection_seconds": 4.659819905000404,
          "observability_ratio": 1.0,
          "recovery_goodput_ratio": 1.0,
          "recovery_seconds": 5.177952623998863,
          "resource_efficiency_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "failure_policy.py",
              "recovery_config.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      }
    ],
    "usage": {
      "agent_time_sec": 5.996131791000153,
      "gpu_minutes": 2.112616015099957,
      "infra_cost_usd": 0.0,
      "model_cost_usd": 0.0,
      "verifier_time_sec": 57.38234866199855,
      "wall_time_sec": 68.16570589700132
    }
  },
  "resolved_at_1": true,
  "schema_version": "0.1",
  "stable_resolved_at_1": true
}
```
