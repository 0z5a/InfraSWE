# InfraSWE Trial 20260831T061211Z-telemetry-root-cause-correlation-dbacb2

- Task: `telemetry-root-cause-correlation`
- State: `COMPLETED`
- Resolved@1: `true`
- StableResolved@1: `true`
- Core-100: `97.182`
- InfraExt-100: `100.000`
- InfraTotal: `98.863`
- Coverage: `100.0%`
- Hard-gate reasons: `none`

## Fresh replays

| Replay | Result | Seconds | Failure |
|---:|---|---:|---|
| 1 | PASS | 0.640 | - |
| 2 | PASS | 0.695 | - |
| 3 | PASS | 0.647 | - |

## Raw score components

```json
{
  "core_100": 97.181979,
  "core_components": {
    "correctness": 1.0,
    "efficiency": 0.718197923980499,
    "fresh_replay": 1.0,
    "protocol": 1.0,
    "regression": 1.0
  },
  "coverage": 1.0,
  "gate": {
    "passed": true,
    "reasons": []
  },
  "infra_components": {
    "fault_recovery": 1.0,
    "observability": 1.0,
    "resource_efficiency": 1.0,
    "safety_rollback": 1.0,
    "slo_goodput": 1.0,
    "topology_robustness": 1.0
  },
  "infra_ext_100": 100.0,
  "infra_total": 98.863116,
  "raw": {
    "catastrophic_gate": true,
    "manifest_valid": true,
    "protocol_gate": true,
    "replays": [
      {
        "assertions": {
          "functional.decoy_log_rejected": true,
          "functional.root_cause_diagnosed": true,
          "mechanism.multi_modal_threshold": true,
          "mechanism.temporal_correlation": true,
          "regression.input_immutable": true,
          "regression.malformed_input_rejected": true,
          "regression.missing_modality_inconclusive": true,
          "regression.order_independent": true,
          "regression.scheduler_cause_correlated": true,
          "regression.tie_break_deterministic": true,
          "regression.timestamp_skew_inconclusive": true,
          "safety.insufficient_evidence_explicit": true,
          "safety.no_evidence_mutation": true,
          "safety.resources_cleaned": true,
          "slo.diagnosis_latency": true
        },
        "duration_sec": 0.6399177389994293,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "missing-signal-modality": true,
            "timestamp-skew": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 1,
        "message": "",
        "metrics": {
          "diagnosis_p95_ms": 0.014310000551631674,
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "diagnoser.py",
              "signal_policy.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.decoy_log_rejected": true,
          "functional.root_cause_diagnosed": true,
          "mechanism.multi_modal_threshold": true,
          "mechanism.temporal_correlation": true,
          "regression.input_immutable": true,
          "regression.malformed_input_rejected": true,
          "regression.missing_modality_inconclusive": true,
          "regression.order_independent": true,
          "regression.scheduler_cause_correlated": true,
          "regression.tie_break_deterministic": true,
          "regression.timestamp_skew_inconclusive": true,
          "safety.insufficient_evidence_explicit": true,
          "safety.no_evidence_mutation": true,
          "safety.resources_cleaned": true,
          "slo.diagnosis_latency": true
        },
        "duration_sec": 0.695378012999754,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "missing-signal-modality": true,
            "timestamp-skew": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 2,
        "message": "",
        "metrics": {
          "diagnosis_p95_ms": 0.014670000382466242,
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "diagnoser.py",
              "signal_policy.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.decoy_log_rejected": true,
          "functional.root_cause_diagnosed": true,
          "mechanism.multi_modal_threshold": true,
          "mechanism.temporal_correlation": true,
          "regression.input_immutable": true,
          "regression.malformed_input_rejected": true,
          "regression.missing_modality_inconclusive": true,
          "regression.order_independent": true,
          "regression.scheduler_cause_correlated": true,
          "regression.tie_break_deterministic": true,
          "regression.timestamp_skew_inconclusive": true,
          "safety.insufficient_evidence_explicit": true,
          "safety.no_evidence_mutation": true,
          "safety.resources_cleaned": true,
          "slo.diagnosis_latency": true
        },
        "duration_sec": 0.6472478870000486,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "missing-signal-modality": true,
            "timestamp-skew": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 3,
        "message": "",
        "metrics": {
          "diagnosis_p95_ms": 0.014399999599845614,
          "observability_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "slo_goodput_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "diagnoser.py",
              "signal_policy.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      }
    ],
    "usage": {
      "agent_time_sec": 0.5744981609996103,
      "gpu_minutes": 0.0,
      "infra_cost_usd": 0.0,
      "model_cost_usd": 0.0,
      "verifier_time_sec": 1.982543638999232,
      "wall_time_sec": 6.961869191000005
    }
  },
  "resolved_at_1": true,
  "schema_version": "0.1",
  "stable_resolved_at_1": true
}
```
