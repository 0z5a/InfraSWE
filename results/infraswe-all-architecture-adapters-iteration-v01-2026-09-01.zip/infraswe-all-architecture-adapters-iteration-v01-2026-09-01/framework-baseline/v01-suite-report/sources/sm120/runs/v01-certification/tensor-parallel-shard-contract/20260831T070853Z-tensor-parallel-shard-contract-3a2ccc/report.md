# InfraSWE Trial 20260831T070853Z-tensor-parallel-shard-contract-3a2ccc

- Task: `tensor-parallel-shard-contract`
- State: `COMPLETED`
- Resolved@1: `true`
- StableResolved@1: `true`
- Core-100: `100.000`
- InfraExt-100: `100.000`
- InfraTotal: `100.000`
- Coverage: `100.0%`
- Hard-gate reasons: `none`

## Fresh replays

| Replay | Result | Seconds | Failure |
|---:|---|---:|---|
| 1 | PASS | 14.354 | - |
| 2 | PASS | 16.939 | - |
| 3 | PASS | 14.278 | - |

## Raw score components

```json
{
  "core_100": 100.0,
  "core_components": {
    "correctness": 1.0,
    "efficiency": 1.0,
    "fresh_replay": 1.0,
    "protocol": 1.0,
    "regression": 1.0
  },
  "coverage": 1.0,
  "gate": {
    "passed": true,
    "reasons": []
  },
  "infra_components": {
    "fault_recovery": 1.0,
    "observability": 1.0,
    "resource_efficiency": 1.0,
    "safety_rollback": 1.0,
    "slo_goodput": 1.0,
    "topology_robustness": 1.0
  },
  "infra_ext_100": 100.0,
  "infra_total": 100.0,
  "raw": {
    "catastrophic_gate": true,
    "manifest_valid": true,
    "protocol_gate": true,
    "replays": [
      {
        "assertions": {
          "functional.all_parameters_reconstructed": true,
          "functional.two_ranks_completed": true,
          "mechanism.column_and_row_axes_enforced": true,
          "mechanism.replicated_parameter_preserved": true,
          "regression.axes_match_contract": true,
          "regression.fallback_not_silent": true,
          "regression.indivisible_dimension_rejected": true,
          "regression.input_immutable": true,
          "regression.order_independent": true,
          "regression.parameter_coverage": true,
          "regression.replication_preserved": true,
          "regression.schema_valid": true,
          "regression.shard_ranges_complete": true,
          "regression.stable_order": true,
          "regression.unclassified_parameter_rejected": true,
          "safety.no_tensor_data_dropped": true,
          "safety.resources_cleaned": true,
          "safety.unclassified_fails_closed": true,
          "slo.collective_latency": true
        },
        "duration_sec": 14.354163271000289,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "indivisible-shard-dimension": true,
            "unclassified-parameter": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 1,
        "message": "",
        "metrics": {
          "collective_ms": 66.22137582302094,
          "observability_ratio": 1.0,
          "reconstruction_goodput_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "shard_policy.py",
              "tp_config.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.all_parameters_reconstructed": true,
          "functional.two_ranks_completed": true,
          "mechanism.column_and_row_axes_enforced": true,
          "mechanism.replicated_parameter_preserved": true,
          "regression.axes_match_contract": true,
          "regression.fallback_not_silent": true,
          "regression.indivisible_dimension_rejected": true,
          "regression.input_immutable": true,
          "regression.order_independent": true,
          "regression.parameter_coverage": true,
          "regression.replication_preserved": true,
          "regression.schema_valid": true,
          "regression.shard_ranges_complete": true,
          "regression.stable_order": true,
          "regression.unclassified_parameter_rejected": true,
          "safety.no_tensor_data_dropped": true,
          "safety.resources_cleaned": true,
          "safety.unclassified_fails_closed": true,
          "slo.collective_latency": true
        },
        "duration_sec": 16.938849595999272,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "indivisible-shard-dimension": true,
            "unclassified-parameter": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 2,
        "message": "",
        "metrics": {
          "collective_ms": 79.72665679454803,
          "observability_ratio": 1.0,
          "reconstruction_goodput_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "shard_policy.py",
              "tp_config.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      },
      {
        "assertions": {
          "functional.all_parameters_reconstructed": true,
          "functional.two_ranks_completed": true,
          "mechanism.column_and_row_axes_enforced": true,
          "mechanism.replicated_parameter_preserved": true,
          "regression.axes_match_contract": true,
          "regression.fallback_not_silent": true,
          "regression.indivisible_dimension_rejected": true,
          "regression.input_immutable": true,
          "regression.order_independent": true,
          "regression.parameter_coverage": true,
          "regression.replication_preserved": true,
          "regression.schema_valid": true,
          "regression.shard_ranges_complete": true,
          "regression.stable_order": true,
          "regression.unclassified_parameter_rejected": true,
          "safety.no_tensor_data_dropped": true,
          "safety.resources_cleaned": true,
          "safety.unclassified_fails_closed": true,
          "slo.collective_latency": true
        },
        "duration_sec": 14.277842628000144,
        "exit_code": 0,
        "failure": null,
        "faults": {
          "checks": {
            "indivisible-shard-dimension": true,
            "unclassified-parameter": true
          },
          "passed": true,
          "score": 1.0
        },
        "index": 3,
        "message": "",
        "metrics": {
          "collective_ms": 66.87766289710999,
          "observability_ratio": 1.0,
          "reconstruction_goodput_ratio": 1.0,
          "resource_efficiency_ratio": 1.0,
          "topology_robustness_ratio": 1.0
        },
        "passed": true,
        "policy": {
          "agent": {
            "changed_paths": [
              "shard_policy.py",
              "tp_config.json"
            ],
            "hard_failures": [],
            "passed": true,
            "violations": []
          },
          "hard_failures": [],
          "passed": true,
          "verifier": {
            "data_corruption": false,
            "hard_failures": [],
            "passed": true,
            "resource_leak": false,
            "silent_fallback": false
          }
        }
      }
    ],
    "usage": {
      "agent_time_sec": 2.4353291819988954,
      "gpu_minutes": 1.6002061558999534,
      "infra_cost_usd": 0.0,
      "model_cost_usd": 0.0,
      "verifier_time_sec": 45.570855494999705,
      "wall_time_sec": 52.76890737499889
    }
  },
  "resolved_at_1": true,
  "schema_version": "0.1",
  "stable_resolved_at_1": true
}
```
